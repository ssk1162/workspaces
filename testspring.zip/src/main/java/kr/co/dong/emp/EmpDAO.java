package kr.co.dong.emp;

import java.util.List;

import kr.co.dong.domain.Emp;

public interface EmpDAO {
	
	public Emp empselect(String name);
	public List<Emp> emplist();
	public int insert(Emp e);
	public int update(Emp e);
	public int delete(String name);
	
}
