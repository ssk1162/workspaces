package kr.co.dong.emp;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import kr.co.dong.domain.Emp;

@Controller
public class empController {

	private static final Logger logger = LoggerFactory.getLogger(empController.class);

//	Service 호출
	@Inject
	private EmpServiceImpl service;

	@GetMapping(value = "/empcount")
	public String empcount(Model model) throws Exception {

		int cnt = service.empCount();
		model.addAttribute("cnt", cnt);

		return "home";
	}

	@GetMapping(value = "/emplist")
	public String emplist(Model model) {

		List<Emp> list = service.emplist();

		model.addAttribute("list", list);

		return "emplist";
	}

	@GetMapping(value = "/empOne")
	public ModelAndView empOne(Model model, @RequestParam("empno") int empno) {

		Emp emp = service.empselect(empno);
		System.out.println(emp);
		ModelAndView mav = new ModelAndView();
		mav.addObject("empone", emp);
		mav.setViewName("empdetail");
		return mav;

	}

	@GetMapping(value="/empinsert")
	public String empin() {
		return "empinsertForm";

	}
	@PostMapping(value="/empinsert")
	public String empinsert(@ModelAttribute("info") Emp emp, Model model) {
		
		model.addAttribute("emp", emp);
		
		return "emplist";
	}
	
}