package kr.co.dong.emp;
/*
 * mybatis 호출 > SqlSession 사용
 * @Repository
 */

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import kr.co.dong.domain.Emp;

@Repository
public class EmpDAOImpl {
	
	@Inject
	private SqlSession sqlSession;
	
	private final static String namespace = "kr.co.dong.empMapper";
	
	public int empCount() throws Exception {
		return sqlSession.selectOne(namespace + ".cnt");
		
	}
	
	public List<Emp> emplist() {
		return sqlSession.selectList(namespace + ".listAll");
	}
	
	public Emp empselect(int empno) {
		return sqlSession.selectOne(namespace + ".selectOne", empno);
	}
	
	public int empinsert(Emp emp) {
		return sqlSession.update(namespace + ".insert", emp);
	}
	
}
