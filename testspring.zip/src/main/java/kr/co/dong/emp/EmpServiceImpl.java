package kr.co.dong.emp;
/*
 * DAO 및 타 클래스를 호출하여 수행
 * @Service
 */

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import kr.co.dong.domain.Emp;

@Service
public class EmpServiceImpl {
	
	@Inject
	private EmpDAOImpl dao;
	
	public int empCount() throws Exception {
		
		return dao.empCount();
	}
	
	public List<Emp> emplist() {
		return dao.emplist();
	}
	
	public Emp empselect(int empno) {
		return dao.empselect(empno);
	}
	
	public int empinsert(Emp emp) {
		return dao.empinsert(emp);
	}
	
}
