package kr.co.dong;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import kr.co.dong.domain.Emp;
import kr.co.dong.emp.EmpServiceImpl;

@Controller
public class SelectController {
	
	private static final Logger logger = LoggerFactory.getLogger(SelectController.class);
	
	@Inject
	private EmpServiceImpl service;
	
//	@GetMapping(value="/emplist")
//	public String empname(Model model) throws Exception {
//		
//		List<Emp> ename = service.emplist();
//		
//		model.addAttribute("listAll", ename);
//		
//		return "home";
//	}
	
//	selectOne
//	@GetMapping(value="/empselect")
//	public String empselect(Model model, HttpServletRequest request) throws Exception {
//		
//		String ename = request.getParameter("name");
//		logger.info(ename);
//		
//		Emp name = service.empselect(ename);
//		
//		model.addAttribute("name", name);			
//		
//		return "home";
//	}
	
	
}
