package kr.co.dong;

import java.io.IOException;
import java.net.http.HttpResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TestController {
	
	private static final Logger logger = LoggerFactory.getLogger(TestController.class);
	
	@RequestMapping(value="/intro", method = RequestMethod.GET)
	public ModelAndView intro() {
		ModelAndView mav = new ModelAndView();
		String msg = "회사소개";
		mav.addObject("msg", msg);
		mav.setViewName("test01");
		return mav;
	}
//	public String intro(Model model) {
//		// 처리
//		String msg = "회사소개";
//		String msg2 = "회사";
//		model.addAttribute("msg", msg);
//		model.addAttribute("msg2", msg2);
//		
//		return "test01";
//	}
	
	@RequestMapping(value="/intro2", method = RequestMethod.GET)
	public String intro2(HttpServletRequest request, Model model, HttpSession session) {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		model.addAttribute("id", id);
		model.addAttribute("pw", pw);
		session.setAttribute("id", id);
		return "test02";
	}
	@RequestMapping(value="/intro3", method = RequestMethod.GET)
	public String test() {
		return "test03";
	}
	
	@RequestMapping(value="/intro4", method= RequestMethod.GET)
	public String test2(HttpServletRequest request, HttpSession session, HttpServletResponse response) {
		
		session = request.getSession();
		
		session.invalidate();
		try {
			response.sendRedirect("home.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "home";
	}
	
	@RequestMapping(value="/main", method=RequestMethod.GET)
	public String main() {
		
//		ModelAndView mav = new ModelAndView();
//		String msg = "main";
//		mav.addObject("msg", msg);
//		mav.setViewName("main");
		
		return "main";
	}
	
	
}
