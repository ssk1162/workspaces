package kr.co.dong.domain;

/*
 * EMPNO int PK 
ENAME varchar(10) 
JOB varchar(9) 
MGR int 
HIREDATE datetime 
SAL double 
COMM double 
DEPTNO int
 */
public class Emp {

	private int empno;
	private String ename;
	private String job;
	private int mgr;
	private double sal;

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getMgr() {
		return mgr;
	}

	public void setMgr(int mgr) {
		this.mgr = mgr;
	}

	public double getSal() {
		return sal;
	}

	public void setSal(double sal) {
		this.sal = sal;
	}

	@Override
	public String toString() {
		return "Emp [empno=" + empno + ", ename=" + ename + ", job=" + job + ", mgr=" + mgr + ", sal=" + sal + "]";
	}

}
