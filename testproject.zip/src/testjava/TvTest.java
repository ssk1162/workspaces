package testjava;

public class TvTest {
	public static void main(String[] args) {
		
		TestClass tc = new TestClass();
		
		
		
	}
	
}
