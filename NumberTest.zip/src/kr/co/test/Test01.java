package kr.co.test;

import java.util.Scanner;

public class Test01 {
	
	public String solution(String my_string, String overwrite_string, int s) {
        String answer = "";
        
        System.out.println(my_string.indexOf(1, 2) + my_string.indexOf(s) + overwrite_string);
        
        return answer;
    }
	
	
	public static void main(String[] args) {

//		Scanner sc = new Scanner(System.in);
//
//		String a = "";
//
//		a = sc.next();
//
//		for (int i = 1; i < a.length(); i++) {
//
//			char c = a.charAt(i);
//
//			if (Character.isLowerCase(c)) {
//				System.out.print((char) (c - 32));
//			} else {
//				System.out.print((char) (c + 32));
//			}
//		}

	}
}
