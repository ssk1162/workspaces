package kr.co.test;

import java.util.Scanner;

public class ExText01 {
	public static void main(String[] args) {

//		int a = 1;
//		int b = 1;
//		
//		boolean c = a != b;
//		
//		System.out.println(c);

//		int a = 0;
//
//		int c = (int) (Math.random() * 100) + 1;
//
//		Scanner sc = new Scanner(System.in);
//
//		do {
//
//			System.out.print("1~100���� ���� �Է� >> ");
//			a = sc.nextInt();
//			if (a < c) {
//				System.out.println("�Է��� ���� �����ϴ�");
//			} else if (a > c) {
//				System.out.println("�Է��� ���� �����ϴ�");
//			}
//		} while (a != c);
//		System.out.println(a + " " + c);
//		System.out.println("�����̴�");


		Scanner sc = new Scanner(System.in);
		int a = 260000;
		int b = sc.nextInt();
		int num = sc.nextInt();
		int age = 0;
		int result = 0;
		
		for (int i = 1; i <= num; i++) {
			int num2 = sc.nextInt();
			int num3 = sc.nextInt();

			age = num2 * num3;
			result += age;
			
		}
		
		if (a != result || b != result || a != b) {
			System.out.println("No");				
		} else {
			System.out.println("Yes");
		}
		
	}
}
