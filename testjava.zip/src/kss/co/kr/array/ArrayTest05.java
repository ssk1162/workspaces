package kss.co.kr.array;

public class ArrayTest05 {
	public static void main(String[] args) {
		
//		p197 ArrayEx7.java �ڵ带 �ؼ��ؼ� �ۼ��غ���
		
		int[] num = new int[10];
		
		for (int i = 0; i < num.length; i++) {
			num[i] = i;
			System.out.print(num[i]);
		}
		System.out.println();
		
		for (int i = 0; i < 20; i++) {
			int n = (int)(Math.random() * 10);
			int tmp = num[0];
			num[0] = num[n];
			num[n] = tmp;
		}
		
		for (int i = 0; i < num.length; i++) {
			System.out.print(num[i]);
		}
		
		
	}
}
