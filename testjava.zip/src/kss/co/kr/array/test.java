package kss.co.kr.array;

import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		String[] soccer = new String[12];

		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < soccer.length; i++) {
			
			soccer[i] = sc.next();
			System.out.println(soccer[i]);
			
		}
		
	}

}
