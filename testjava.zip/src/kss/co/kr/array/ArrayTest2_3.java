package kss.co.kr.array;

import java.util.Scanner;

public class ArrayTest2_3 {
	public static void main(String[] args) {

		String[] name = null;
		String[] hi = null;
		String[] bl = null;
		Scanner sc = null;
		sc = new Scanner(System.in);

		int size = 5;

		name = new String[size];
		hi = new String[size];
		bl = new String[size];

		for (int i = 0; i < name.length; i++) {
			for (int j = 0; j < hi.length; i++) {
				for (int c = 0; c < bl.length; i++) {
					System.out.print("�̸��� >> ");
					name[i] = sc.next();
					System.out.print("����� >> ");
					hi[j] = sc.next();
					System.out.print("�������� >> ");
					bl[c] = sc.next();

					System.out.println("�̸��� " + name[i] + " ��̴� " + hi[j] + " �������� " + bl[c]);
				}
			}
		}

	}

}
