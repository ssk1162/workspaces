package kss.co.kr.array;

import java.util.Scanner;

public class ArrayTest02 {
	public static void main(String[] args) {
		
//		01���� �����͸� �ַܼ� �Է� �޾Ƽ� ����Ѵ�
		
//		Scanner sc = new Scanner(System.in);
		
//		����
		
		String[] dt2 = null;
		Scanner scan = null;
		int size =4;
		scan = new Scanner(System.in);
//		����
		
		dt2 = new String[size];
		System.out.print("1st Drink Name : ");
		dt2[0] = scan.nextLine();
		System.out.print("2st Drink Name : ");
		dt2[1] = scan.nextLine();
		System.out.print("3st Drink Name : ");
		dt2[2] = scan.nextLine();
		System.out.print("4st Drink Name : ");
		dt2[3] = scan.nextLine();
//		ó��
		
		for (int i = 0; i < dt2.length; i++) {
			dt2[i] = scan.nextLine();
			System.out.println(i + "st Drink Name : " + dt2[i]);
			
		}
		
		
//		���
		
		System.out.println("1st Drink Name : " + dt2[0]);
		System.out.println("2st Drink Name : " + dt2[1]);
		System.out.println("3st Drink Name : " + dt2[2]);
		System.out.println("4st Drink Name : " + dt2[3]);
		
		
		
		
		
		
//		String[] dt = new String[5];
//		
//		
//		for (int i = 0; i < dt.length; i++) {
//			
//			System.out.println("������ �Է� >> ");
//			dt[i] = sc.next();
//			System.out.println("dt [" + i + "] = " + dt[i]);
//		}
		
	}
}
