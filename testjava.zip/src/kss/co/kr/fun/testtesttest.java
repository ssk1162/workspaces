package kss.co.kr.fun;

public class testtesttest {
	public static void main(String[] args) {
		
		Human hm = new Human();
		
		hm.�޸���();
		hm.����();
		hm.workOut();
		
	}
}
