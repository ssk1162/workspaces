package kss.co.kr.fun;

public interface Sportsable {
	void workOut();	// ��ϴ�
	
}
