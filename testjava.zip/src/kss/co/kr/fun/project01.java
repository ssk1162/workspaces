package kss.co.kr.fun;

import java.util.List;

import kss.co.kr.array.Student;

public class project01 {
	public static void main(String[] args) {

		Student s1 = null;
		Student s2 = null;
		Student s3 = null;
		Student s4 = null;
		Student s5 = null;
		Student s6 = null;
		Student s7 = null;
		Student s8 = null;
		Student s9 = null;
		Student s10 = null;
		
		
//		List<Student> list = null;
//		list.add(s1);

	}
}
