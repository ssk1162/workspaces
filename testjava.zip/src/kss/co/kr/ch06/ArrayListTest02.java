package kss.co.kr.ch06;

import java.util.ArrayList;

public class ArrayListTest02 {
	public static void main(String[] args) {

//		3���� ������������� �Է��ϰ� ���

		ArrayList<Account> list = new ArrayList<Account>();

		Account ac1 = new Account("123", "123", 10000);
		Account ac2 = new Account("321", "321", 20000);
		Account ac3 = new Account("132", "312", 30000);
		Account ac4 = new Account("312", "312", 40000);

		list.add(ac1);
		list.add(ac2);
		list.add(ac3);
		list.add(ac4);

		for (int i = 0; i < list.size(); i++) {
			Account obj = list.get(i);
			System.out.println(obj);
//			System.out.println(obj.accountNum);
//			System.out.println(obj.owerNmae);
//			System.out.println(obj.balance);
		}
		System.out.println("===========================");

//		�����ֿ� �ܾ׸�
		for (int i = 0; i < list.size(); i++) {
			Account obj = list.get(i);
			System.out.println("������ " + obj.owerNmae);
			System.out.println("�ܾ� " + obj.balance);
		}
		System.out.println("===========================");
		for (int i = 0; i < list.size(); i++) {
//			Account obj = list.get(i);
			System.out.println("������ " + list.get(i).owerNmae);
			System.out.println("�ܾ� " + list.get(i).balance);
		}

		System.out.println("===========================");
//		��� for
		for (Account obj : list) {
			System.out.println("������ " + obj.owerNmae);
			System.out.println("�ܾ� " + obj.balance);

		}

	}

}
