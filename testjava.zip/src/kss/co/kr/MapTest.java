package kss.co.kr;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapTest {
	public static void main(String[] args) {
		
		Map<Integer, String> map = new HashMap<Integer, String>();
		
		map.put(1, "��");
		map.put(2, "��");
		map.put(3, "��");
		map.put(4, "��");

		Set<Map.Entry<Integer, String>> keySet = map.entrySet();
		
		Iterator<Map.Entry<Integer, String>> it = keySet.iterator();
		
		while (it.hasNext()) {
			Map.Entry<Integer, String> ent = it.next();
			int ent2 = ent.getKey();
			String ent3 = ent.getValue();
			System.out.println(ent2 + " : " + ent3);
		}
		
	}
}
