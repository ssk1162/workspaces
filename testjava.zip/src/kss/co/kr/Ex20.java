package kss.co.kr;

public class Ex20 {
	public static void main(String[] args) {

//		// 4-4
//		int num = 0;
//		int s = 1;
//		int sum = 0;
//		
//		for (int i = 1; sum < 100; i++, s = -s) {
		// s = -s : 1 -1 1 -1 / n = n * -1
//			num = i * s;	// 1 ~ -2
//			sum += num;		// 
//			System.out.println(num);
//			System.out.println(sum);
//			
//		}

//		// 4-3
//		int sum = 0;
//		int sum2 = 0;
//		
//		for (int i = 1; i <= 10; i++) {
//			
//			sum += i;
//			sum2 += sum;
//			System.out.println(sum2);
//			
//		}

//		//4-2
//		int sum = 0;
//		
//		for (int i = 1; i <= 20; i++) {
//			//  !(i % 2 == 0 || i % 3 == 0)
//			if (i % 2 != 0 && i % 3 != 0) {
//				sum += i;
//				System.out.println(sum);
//			}
//			
//		}

//		// 4-11
//		int num1 = 1;
//		int num2 = 1;
//		int num3 = 0;
//
//		System.out.print(num1 + ", " + num2);
//
//		for (int i = 0; i < 8; i++) {
//
//			num3 = num1 + num2; // 2, 3, 5
//			System.out.print(", " + num3);
//			num1 = num2;	// 1, 1, 2
//			num2 = num3;	// 2, 3, 5
//		}

//		//4-15
//		int number = 12345;
//		int tmp = number; // ���� ���ؾߵǼ� ���� ���� ����
//		
//		int result = 0;
//		
////		System.out.print(tmp % 10);
//		while (tmp != 0) {
//			result = result * 10 + tmp % 10;
//			// 1. result = 0 = 0 + 5
//			// 2. result = 5 = 50 + 4
//			// result = 54321
//			tmp = tmp/10;
//			// 1-1. (int) 12345 > 1234.5 = 1234
//			System.out.println(tmp);
//			System.out.println(tmp + " " + result );
//		}
//		if (number == result) {
//			System.out.println(number + " ȸ���� ����");
//		} else {
//			System.out.println(number + " ȸ���� �ƴ�");
//		}

//		//4-14
//		int answer = (int) (Math.random() * 100) + 1; // 1��
//		int input = 0;
//		int count = 0;
//		
//		java.util.Scanner s = new java.util.Scanner(System.in);
//		
//		do {
//			count++;
//			System.out.print("1~100���� ���� �ϳ� �Է� >> ");
//			input = s.nextInt();
//			
//			if (input > answer) {						// 2��
//				System.out.println("�� �������� �Է�");
//			} else if (input < answer) {
//				System.out.println("�� ū���� �Է�");
//			} else {
//				System.out.println("������ϴ�");
//				break;
//			}
//			System.out.println("�õ�Ƚ���� " + count + "�� �Դϴ�");
//			
//		} while (true);

//		// 4-13
//		String value = "12o34";
//		char ch = ' ';
//		boolean isNumber = true;
//
//		for (int i = 0; i < value.length(); i++) {
//
//			ch = value.charAt(i);
//			if (!(ch >= '0' && ch <= '9')) {
//				isNumber = false;
//				break;
//			}
//		}
//		if (isNumber) {
//			System.out.println(value + " " + ch + " ����");
//		} else {
//			System.out.println(value + " " + ch + " �ƴ�");
//		}

		// 4-10
		int num = 12345;
		int sum = 0;
		int tmp = 0;
		
		tmp = num;	// �ʱⰪ ����
		
		
		 while(tmp > 0) {
			 sum = sum + tmp % 10;
		//	   0 =  0  + (12345 % 10 = 5)
			 tmp = tmp / 10;
		//	1234 = 12345 / 10 = 1234.5
			 System.out.println(tmp);
	        }
		 
		 System.out.println(num + "of Sum : " + sum);
		 

//		// 4-8
//		for (int x = 0; x <= 10; x++) {
//
//			for (int y = 0; y <= 10; y++) {
//				
//				if ((x * 2) + (y * 4) == 10) {
//					System.out.println(x + " " + y);
//				}
//			}
//
//		}

//		// 4-9
//		String str = "12345";
//		int sum = 0;
//		
//		for (int i = 0; i < str.length(); i++) {
//			
//			// System.out.println(sum += str.charAt(i));
//			// �ƽ�Ű �ڵ� 1 = 49�� ��ȯ�ؼ� ~ 5 = 53���� ����
//			
//			sum += str.charAt(i) - '0';
//			// �ڵ� ������ 0 = 48
//			// �� ������ 1 - 0 == 49 - 48 = 1
//						
//			System.out.println(sum);
//
//		}

		// 4-5
//		int a = 0;
//		while (a <= 10) {
//
//			int b = 0;
//
//			while (b <= a) {
//				System.out.print("*");
//				b++;
//			}
//			System.out.println();
//			a++;
//		}

	}
}
