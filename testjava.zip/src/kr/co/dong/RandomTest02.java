package kr.co.dong;

public class RandomTest02 {

	public static void main(String[] args) {

		//		�ֻ��� 2���� ���� 10���ϸ� ��÷! , �ƴϸ� �̴�÷!
	
		/*	 �ֻ��� �� 1~6������ ��� ���� �����ϴ� math�� ����� 
	 	�װ� ������ �־ �� ���� result�� ���� if������ ǥ���غ���	 */
	
		int dice1 = 0;
		int dice2 = 0;
		int db = 0;
		
		System.out.println("                                                                                            ");
		System.out.println("                                                     �ƽ�Ű��Ʈ ��ó https://ascii.co.uk/text   ");
		System.out.println("          88 88                                                                             ");
		System.out.println("          88 \"\"                                                                            ");
		System.out.println("          88                                                                                ");
		System.out.println("  ,adPPYb,88 88  ,adPPYba,  ,adPPYba,  ,adPPYb,d8 ,adPPYYba, 88,dPYba,,adPYba,   ,adPPYba,  ");
		System.out.println(" a8\"    `Y88 88 a8\"     \"\" a8P_____88 a8\"    `Y88 \"\"     `Y8 88P'   \"88\"    \"8a a8P_____88  ");
		System.out.println(" 8b       88 88 8b         8PP\"\"\"\"\"\"\" 8b       88 ,adPPPPP88 88      88      88 8PP\"\"\"\"\"\"\" ");
		System.out.println(" \"8a,   ,d88 88 \"8a,   ,aa \"8b,   ,aa \"8a,   ,d88 88,    ,88 88      88      88 \"8b,   ,aa  ");
		System.out.println("  `\"8bbdP\"Y8 88  `\"Ybbd8\"'  `\"Ybbd8\"'  `\"YbbdP\"Y8 `\"8bbdP\"Y8 88      88      88  `\"Ybbd8\"'");
		System.out.println("                                       aa,    ,88                                          ");
		System.out.println("                                       \"Y8bbdP\"                                            ");
		

		dice1 =((int)(Math.random() * 6) +1);
		dice2 =((int)(Math.random() * 6) +1);
		
		db = dice1 + dice2;
		
		System.out.println("\r============================= 1�� �ֻ���: |" + dice1 + "| ==== 2�� �ֻ���: |" + dice2 +"| =============================");
		
		
		if (db <= 6) {
			
			System.out.println("========================================== ��!��÷! ==========================================");
		}
		
		else {
			System.out.println("\r========================================== �ƽ��׿�! ==========================================");
		}
		
	}

}
