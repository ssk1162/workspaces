package kr.co.dong.good;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCTemplate {

	public static Connection getConnection() {
		Connection conn = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			String url = "jdbc:mysql://localhost/testdb2?characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false";
			String id = "root";
			String pw = "12345";

			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("���� ����");

		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
			System.out.println("���� ����̺갡 ����");

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			System.out.println("���� : ");

		}

		return conn;
	}
//	conn, stmt, pstmt, rs > close() �ؾߴ�

	public static void close(Connection conn) {
		try {
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void close(Statement stmt) {
		try {
			if (stmt != null && !stmt.isClosed()) {
				stmt.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void close(PreparedStatement pstmt) {
		try {
			if (pstmt != null && !pstmt.isClosed()) {
				pstmt.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void close(ResultSet rs) {
		try {
			if (rs != null && !rs.isClosed()) {
				rs.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
