package kr.co.dong.good;

public class RunGoods {
	public static void main(String[] args) {
		
		GoodsMenu gmenu = new GoodsMenu();
		
		gmenu.displayMenu();
		
	}
}
