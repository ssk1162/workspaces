package kr.co.dong.good.copy;

public class StudentRun {
	public static void main(String[] args) {
		
		StudentMain sm = new StudentMain();
		
		sm.displayMain();
		
	}
}
