package kr.co.dong.good.copy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import static kr.co.dong.good.copy.JDBCTemplate.*;

public class StudentDAOImpl implements StudentDAO {

	Connection con = getConnection();

	@Override
	public List<StudentBean> listAll() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<StudentBean> list = new ArrayList<StudentBean>();

		String sql = "select * from student";

		try {
			ps = con.prepareStatement(sql);

			rs = ps.executeQuery();

			while (rs.next()) {
				list.add(new StudentBean(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5)));
			}
			
			for (StudentBean sb : list) {
				System.out.println(sb);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(con);
		}

		return list;
	}

	@Override
	public StudentBean selectOne(int sid) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		StudentBean sb = null;

		String sql = "select * from student where sid = ?";

		try {
			ps = con.prepareStatement(sql);

			ps.setInt(1, sid);

			rs = ps.executeQuery();

			while (rs.next()) {
				sb = new StudentBean(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5));
			}
			
			System.out.println(sb);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(con);
			close(rs);
		}

		return sb;
	}

	@Override
	public int update(StudentBean sb) {
		PreparedStatement ps = null;
		int result = 0;

		String sql = "update student set name = ?, age = ?, num = ?, major = ? where sid = ?";

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, sb.getName());
			ps.setInt(2, sb.getAge());
			ps.setInt(3, sb.getNum());
			ps.setString(4, sb.getMajor());
			ps.setInt(5, sb.getSid());

			result = ps.executeUpdate();

			if (result <= 0) {
				System.out.println("���� ����");
			} else {
				System.out.println("���� ����");
			}
			
			System.out.println(sb);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(con);
		}

		return result;
	}

	@Override
	public int insert(StudentBean sb) {
		PreparedStatement ps = null;
		int result = 0;

		String sql = "insert into student (name, age, num, major) values (?,?,?,?)";

		try {
			ps = con.prepareStatement(sql);

			ps.setString(1, sb.getName());
			ps.setInt(2, sb.getAge());
			ps.setInt(3, sb.getNum());
			ps.setString(4, sb.getMajor());

			result = ps.executeUpdate();

			if (result <= 0) {
				System.out.println("���� ����");
			} else {
				System.out.println("���� ����");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(con);
		}

		return result;
	}

	@Override
	public int delete(int sid) {
		PreparedStatement ps = null;
		int result = 0;

		String sql = "delete from student where sid = ?";

		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, sid);

			result = ps.executeUpdate();

			if (result <= 0) {
				System.out.println("���� ����");
			} else {
				System.out.println("���� ����");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(con);
		}

		return result;
	}
}
