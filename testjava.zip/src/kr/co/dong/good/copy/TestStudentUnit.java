package kr.co.dong.good.copy;

import java.util.ArrayList;
import java.util.List;

public class TestStudentUnit {
	public static void main(String[] args) {
		
		StudentDAOImpl sdao = new StudentDAOImpl();
		List<StudentBean> list = new ArrayList<StudentBean>();
		
		list = sdao.listAll();
		
		for (StudentBean sb : list) {
			System.out.println(sb);
		}
		
	}
}
