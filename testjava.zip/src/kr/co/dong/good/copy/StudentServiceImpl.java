package kr.co.dong.good.copy;

import java.util.List;

public class StudentServiceImpl implements StudentService {
	
	StudentDAOImpl sdao = new StudentDAOImpl();
	
	@Override
	public List<StudentBean> listAll() {
		// TODO Auto-generated method stub
		return sdao.listAll();
	}

	@Override
	public StudentBean selectOne(int sid) {
		// TODO Auto-generated method stub
		return sdao.selectOne(sid);
	}

	@Override
	public int delete(int sid) {
		// TODO Auto-generated method stub
		return sdao.delete(sid);
	}

	@Override
	public int update(StudentBean sb) {
		// TODO Auto-generated method stub
		return sdao.update(sb);
	}

	@Override
	public int insert(StudentBean sb) {
		// TODO Auto-generated method stub
		return sdao.insert(sb);
	}

}
