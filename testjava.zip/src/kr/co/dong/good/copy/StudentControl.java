package kr.co.dong.good.copy;

import java.util.List;

public class StudentControl {

	StudentServiceImpl ssi = new StudentServiceImpl();

	public void listAll() {
		List<StudentBean> list = ssi.listAll();

		if (list.isEmpty()) {
			System.out.println("��ȸ ����� ����");
		} else {
			System.out.println("��ü ��ȸ");
		}

	}

	public void selectOne(int sid) {

		StudentBean sb = ssi.selectOne(sid);

		if (sb == null) {
			System.out.println("�ٽ� �Է�");
		} else {
			System.out.println("��ȸ");
		}

	}

	public void update(StudentBean stb, int sid) {

		StudentBean sb = ssi.selectOne(sid);

		if (sb == null) {
			System.out.println("����");
			return;
		}

		stb.setSid(sid);
		int result = ssi.update(stb);

		if (result > 0) {
			System.out.println("���� �Ϸ�");
		} else {
			System.out.println("���� ����");
		}

	}

	public void insert(StudentBean sb) {
		int result = ssi.insert(sb);

		if (result > 0) {
			System.out.println("���� �Ϸ�");
		} else {
			System.out.println("���� ����");
		}

	}

}
