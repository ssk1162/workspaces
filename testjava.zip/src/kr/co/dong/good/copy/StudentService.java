package kr.co.dong.good.copy;

import java.util.List;

public interface StudentService {
	
	public List<StudentBean> listAll();
	public StudentBean selectOne(int sid);
	public int delete(int sid);
	public int update (StudentBean sb);
	public int insert (StudentBean sb);
	
}
