package kr.co.dong.good;

import java.util.List;

public class GoodsServiceImpl implements GoodsService {
//	���񽺴� DAO�� ȣ����
	GoodsDAOImpl gadao = new GoodsDAOImpl();
	
	@Override
	public List<GoodsBean> listAll() {
		// TODO Auto-generated method stub
		return gadao.listAll();
	}

	@Override
	public int insert(GoodsBean g) {
		// TODO Auto-generated method stub
		return gadao.insert(g);
	}

	@Override
	public GoodsBean selectOne(int gid) {
		// TODO Auto-generated method stub
		return gadao.selectOne(gid);
	}

	@Override
	public int update(GoodsBean g) {
		// TODO Auto-generated method stub
		return gadao.update(g);
	}

	@Override
	public int delete(int gid) {
		// TODO Auto-generated method stub
		return gadao.delete(gid);
	}
	
	
	
}
