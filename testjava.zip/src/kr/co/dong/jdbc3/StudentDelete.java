package kr.co.dong.jdbc3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class StudentDelete {
	public static void main(String[] args) {
		
		Connection con = null;
		PreparedStatement ps = null;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("������ ������ �Է� : ");
		int sid = Integer.parseInt(sc.nextLine());
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url = "jdbc:mysql://localhost/testdb?characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false";
			String id = "root";
			String pw = "12345";
			
			con = DriverManager.getConnection(url, id, pw);
			System.out.println("���� �Ϸ�");
			String sql = "delete from student where sid = ?";
			
			ps = con.prepareStatement(sql);
			ps.setInt(1, sid);
			
			ps.executeUpdate();
					
		} catch (ClassNotFoundException cnfe) {
			// TODO Auto-generated catch block
			cnfe.printStackTrace();
		} catch (SQLException sqle) {
			// TODO Auto-generated catch block
			sqle.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
}
