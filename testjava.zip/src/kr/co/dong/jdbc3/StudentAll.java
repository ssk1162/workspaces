package kr.co.dong.jdbc3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentAll {
	public static void main(String[] args) {
		boolean power = false;
		Connection con = null;
		ResultSet rs = null;
		StudentBean sb = null;
		List<StudentBean> list = new ArrayList<StudentBean>();
		PreparedStatement ps = null;
		Scanner sc = new Scanner(System.in);

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			String url = "jdbc:mysql://localhost/testdb?characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false";
			String id = "root";
			String pw = "12345";

			con = DriverManager.getConnection(url, id, pw);
			System.out.println("���� �Ϸ�");
			String sql = "select * from student";

			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();

			while (rs.next()) {
				sb = new StudentBean(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5));
				list.add(sb);
			}

			while (!power) {

				System.out.print("��ȣ �Է� : ");
				int num4 = sc.nextInt();
				int idx = -1;

				for (int i = 0; i < list.size(); i++) {
					if (num4 == list.get(i).getSid()) {
						idx = i;
						break;
					}
				}

				if (idx != -1) {
					System.out.println(list.get(idx));
				}

				break;

			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}
