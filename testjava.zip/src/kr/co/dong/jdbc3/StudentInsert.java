package kr.co.dong.jdbc3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class StudentInsert {
	public static void main(String[] args) {

		Connection con = null;
		PreparedStatement ps = null;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("���� �Է� (00) : ");
		int sid = Integer.parseInt(sc.nextLine());
		System.out.print("�̸� �Է� : ");
		String name = sc.nextLine();
		System.out.print("���� �Է� : ");
		int age = Integer.parseInt(sc.nextLine());
		System.out.print("�й� �Է� (20230000): ");
		int num = Integer.parseInt(sc.nextLine());
		System.out.print("�а� �Է� : ");
		String major = sc.nextLine();
		

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			String url = "jdbc:mysql://localhost/testdb?characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false";
			String id = "root";
			String pw = "12345";

			con = DriverManager.getConnection(url, id, pw);
			System.out.println("��� �Ϸ�");
			String sql = "insert into student (sid, name, age, num, major)";
					sql += "values (?,?,?,?,?)";
					
			ps = con.prepareStatement(sql);
			ps.setInt(1, sid);
			ps.setString(2, name);
			ps.setInt(3, age);
			ps.setInt(4, num);
			ps.setString(5, major);
			
			ps.executeUpdate();
			
		} catch (ClassNotFoundException cnfe) {
			// TODO Auto-generated catch block
			cnfe.printStackTrace();
		} catch (SQLException sqle) {
			// TODO Auto-generated catch block
			sqle.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}
