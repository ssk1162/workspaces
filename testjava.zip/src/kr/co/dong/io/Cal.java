package kr.co.dong.io;

public class Cal implements Calable {

	@Override
	public int sum(int num, int num2) {
		// TODO Auto-generated method stub
		return num + num2;
	}

	@Override
	public int miuns(int num, int num2) {
		// TODO Auto-generated method stub
		return num - num2;
	}

	@Override
	public int mul(int num, int num2) {
		// TODO Auto-generated method stub
		return num * num2;
	}

	@Override
	public double div(int num, int num2) throws Exception {
		// TODO Auto-generated method stub
		double result = 0;
//		try {
			result = (double)num / num2;
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		return result;
	}

	@Override
	public int clear(int c) {
		// TODO Auto-generated method stub
		return 0;
	}

}
