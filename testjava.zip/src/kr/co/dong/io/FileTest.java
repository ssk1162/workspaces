package kr.co.dong.io;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileTest {
	public static void main(String[] args) {

//		poem.txt ������ �о output2.txt ���Ϸ� ����

		FileReader reader = null;
		FileWriter writer = null;
		String filename = "poem.txt";
		String filename2 = "output2.txt";
		
		try {
			reader = new FileReader(filename);
			writer = new FileWriter(filename2);
			int data = 0;
			while (true) {
				int data1 = reader.read();
				if (data1 < 0) {
					break;
				}
				writer.write(data1);
			}
			
//			while (data != -1) {
//				data = reader.read();
//				writer.write(data);
//			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				reader.close();
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("end");

	}
}
