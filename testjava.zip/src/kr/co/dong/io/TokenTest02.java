package kr.co.dong.io;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.StringTokenizer;

public class TokenTest02 {
	public static void main(String[] args) {

//		student.txt ������ �о �޸��� �����ϰ� ����ϱ�
//		Ȳ����,30,1,���� > Ȳ���� 30 1 ����
		BufferedReader br = null;
		StringTokenizer st = null;
		
		try {
			
			br = new BufferedReader(new FileReader("student.txt"));
			
			while (true) {
				String str = br.readLine();
				if (str == null) {
					break;
				}
				st = new StringTokenizer(str, ",");
				int cnt = st.countTokens();
				for (int i = 0; i < cnt; i++) {
					String data = st.nextToken();
					System.out.print(data + " ");
				}
				System.out.println();
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}
