package kr.co.dong.io;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class LineNumReaderTest {
	public static void main(String[] args) {
		
//		������ �о ���ȣ �ٿ��� �ַܼ� ���
		
		LineNumberReader ln = null;
		
		try {
			ln = new LineNumberReader(new FileReader("poem.txt"));
			
			while (true) {
				String str = ln.readLine();
				if (str == null) {
					break;
				}
				int lineNo = ln.getLineNumber();
				System.out.println(lineNo + ". " + str);
			}
			
		} catch (FileNotFoundException fnfe) {
			// TODO Auto-generated catch block
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		
		
	}
}
