package kr.co.dong;

import java.util.Scanner;

public class ForTest10 {
	public static void main(String[] args) {
		
//		�������� �ܼ��� �Է¹޾Ƽ� ���� ����ϼ���
		
		Scanner sc = new Scanner(System.in);
		
		int dan = 0; // �ܼ�
		int result = 0; // �����
		int count = 0;
		int count2 = 0;
		int count3 = 0;
		
		System.out.print("�ܼ� �Է� >> ");
		dan = sc.nextInt();
		
		for (int i = 1; i <= 9; i++) {
			
			result = dan * i;
			
			System.out.println(dan + " * " + i + " = " + result);
		}
		
		System.out.println("--------------------------------------------------");
		count++;
		for (dan = 2; dan <= 9; dan++) {
			
			System.out.println(dan + "��");
			count2++;
			
			for (int i = 1; i <= 9; i++) {
				
				result = dan * i;
				
				System.out.print(dan + " * " + i + " = " + result + "\t");
				count3++;
			}
			System.out.println();
			
		}
		System.out.println(count + " " + count2 + " " + count3);
		
	}
}
