package kr.co.dong.room;

import java.util.List;

public interface RoomDAO {

	public List<RoomBean> listAll();

	public int insert(RoomBean rb);

	public RoomBean selectOne(int r_num);

	public int update(RoomBean rb);

	public int delete(int r_num);

}
