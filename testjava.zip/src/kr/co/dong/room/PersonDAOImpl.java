package kr.co.dong.room;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import static kr.co.dong.room.JDBCTemplate.*;

public class PersonDAOImpl implements PersonDAO {
	
	Connection con = getConnection();
	
	@Override
	public List<PersonBean> listAll() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<PersonBean> list = new ArrayList<PersonBean>();
		
		String sql = "select * from person";
		
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				list.add(new PersonBean(rs.getString(1), rs.getInt(2), rs.getInt(3)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
	}

	@Override
	public int insert(PersonBean rb) {
		PreparedStatement ps = null;
		int r = 0;
		String sql = "insert into person (p_name, p_money) values (?,?)";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, rb.getP_name());
			ps.setInt(2, rb.getP_monay());
			r = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return r;
	}

	@Override
	public PersonBean selectOne(String name) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		PersonBean pb = null;
		String sql = "select * from person where p_name=?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, name);
			rs = ps.executeQuery();
			while (rs.next()) {
				pb = new PersonBean(rs.getString(1), rs.getInt(2), rs.getInt(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return pb;
	}

	@Override
	public int update(PersonBean rb) {
		PreparedStatement ps = null;
		int r = 0;
		
		String sql = "update person set p_name=? where p_name=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, rb.getP_name());
			r = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return r;
	}

	@Override
	public int delete(String name) {
		
		return 0;
	}

}
