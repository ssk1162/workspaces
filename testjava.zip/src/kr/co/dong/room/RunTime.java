package kr.co.dong.room;

public class RunTime {
	
	public static void main(String[] args) {
		
		HotelMain hm = new HotelMain();
		
		hm.ViewMain();
		
	}
	
}
