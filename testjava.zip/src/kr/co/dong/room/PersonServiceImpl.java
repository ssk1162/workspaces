package kr.co.dong.room;

import java.util.List;

public class PersonServiceImpl implements PersonService {
	
	PersonDAOImpl pdao = new PersonDAOImpl();
	
	@Override
	public List<PersonBean> listAll() {
		// TODO Auto-generated method stub
		return pdao.listAll();
	}

	@Override
	public int insert(PersonBean rb) {
		// TODO Auto-generated method stub
		return pdao.insert(rb);
	}

	@Override
	public PersonBean selectOne(String name) {
		// TODO Auto-generated method stub
		return pdao.selectOne(name);
	}

	@Override
	public int update(PersonBean rb) {
		// TODO Auto-generated method stub
		return pdao.update(rb);
	}

	@Override
	public int delete(String name) {
		// TODO Auto-generated method stub
		return pdao.delete(name);
	}

}
