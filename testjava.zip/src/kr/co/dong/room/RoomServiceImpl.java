package kr.co.dong.room;

import java.util.List;

public class RoomServiceImpl implements RoomDAO {

	RoomDAOImpl rdao = new RoomDAOImpl();

	@Override
	public List<RoomBean> listAll() {
		// TODO Auto-generated method stub
		return rdao.listAll();
	}

	@Override
	public int insert(RoomBean rb) {
		// TODO Auto-generated method stub
		return rdao.insert(rb);
	}

	@Override
	public RoomBean selectOne(int r_num) {
		// TODO Auto-generated method stub
		return rdao.selectOne(r_num);
	}

	@Override
	public int update(RoomBean rb) {
		// TODO Auto-generated method stub
		return rdao.update(rb);
	}

	@Override
	public int delete(int r_num) {
		// TODO Auto-generated method stub
		return rdao.delete(r_num);
	}

}
