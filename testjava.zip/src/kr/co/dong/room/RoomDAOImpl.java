package kr.co.dong.room;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import static kr.co.dong.room.JDBCTemplate.*;

public class RoomDAOImpl implements RoomDAO {

	Connection con = getConnection();

	@Override
	public List<RoomBean> listAll() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<RoomBean> list = new ArrayList<RoomBean>();

		String sql = "select * from room";
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				list.add(new RoomBean(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getInt(4), rs.getString(5)));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return list;
	}

	@Override
	public int insert(RoomBean rb) {
		PreparedStatement ps = null;
		int r = 0;

		String sql = "insert into room (r_num, r_name, r_pay, r_content) values (?,?,?,?)";

		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, rb.getR_num());
			ps.setString(2, rb.getR_name());
			ps.setInt(3, rb.getR_pay());
			ps.setString(4, rb.getR_content());
			r = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return r;
	}

	@Override
	public RoomBean selectOne(int r_num) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		RoomBean rb = null;

		String sql = "select * from room where r_num=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, r_num);
			rs = ps.executeQuery();
			while (rs.next()) {
				rb = new RoomBean(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getInt(4), rs.getString(5));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return rb;
	}

	@Override
	public int update(RoomBean rb) {
		PreparedStatement ps = null;
		int r = 0;

		String sql = "update room set r_num=?, r_name=?, r_pay=?, r_content=? where r_id=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, rb.getR_num());
			ps.setString(2, rb.getR_name());
			ps.setInt(3, rb.getR_pay());
			ps.setString(4, rb.getR_content());
			ps.setInt(5, rb.getR_id());
			r = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return r;
	}

	@Override
	public int delete(int r_num) {
		PreparedStatement ps = null;
		int r = 0;

		String sql = "delete from room where r_num=?";

		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, r_num);
			r = ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return r;
	}

}
