package kr.co.dong.room;

/*
 * Table: person
Columns:
p_name varchar(45) 
p_money int 
p_id int
 */
public class PersonBean {
	private String p_name;
	private int p_monay;
	private int p_id;

	public PersonBean(String p_name, int p_monay, int p_id) {
		super();
		this.p_name = p_name;
		this.p_monay = p_monay;
		this.p_id = p_id;
	}

	public PersonBean(String p_name, int p_monay) {
		super();
		this.p_name = p_name;
		this.p_monay = p_monay;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public int getP_monay() {
		return p_monay;
	}

	public void setP_monay(int p_monay) {
		this.p_monay = p_monay;
	}

	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	@Override
	public String toString() {
		return "PersonBean [p_name=" + p_name + ", p_monay=" + p_monay + ", room_r_id=" + p_id + "]";
	}

}
