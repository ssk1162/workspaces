package kr.co.dong.room;

/*
 * Table: room
Columns:
r_id int AI PK 
r_num int 
r_name varchar(45) 
r_pay int 
r_content varchar(45)
 */
public class RoomBean {
	private int r_id;
	private int r_num;
	private String r_name;
	private int r_pay;
	private String r_content;

	public RoomBean(int r_id, int r_num, String r_name, int r_pay, String r_content) {
		super();
		this.r_id = r_id;
		this.r_num = r_num;
		this.r_name = r_name;
		this.r_pay = r_pay;
		this.r_content = r_content;
	}

	public RoomBean(int r_num, String r_name, int r_pay, String r_content) {
		super();
		this.r_num = r_num;
		this.r_name = r_name;
		this.r_pay = r_pay;
		this.r_content = r_content;
	}

	public int getR_id() {
		return r_id;
	}

	public void setR_id(int r_id) {
		this.r_id = r_id;
	}

	public int getR_num() {
		return r_num;
	}

	public void setR_num(int r_num) {
		this.r_num = r_num;
	}

	public String getR_name() {
		return r_name;
	}

	public void setR_name(String r_name) {
		this.r_name = r_name;
	}

	public int getR_pay() {
		return r_pay;
	}

	public void setR_pay(int r_pay) {
		this.r_pay = r_pay;
	}

	public String getR_content() {
		return r_content;
	}

	public void setR_content(String r_content) {
		this.r_content = r_content;
	}

	@Override
	public String toString() {
		return r_id + "�� / ���ȣ " + r_num + "ȣ / ���̸� " + r_name + " / ���� " + r_pay
				+ "�� / ���� " + r_content;
	}

}
