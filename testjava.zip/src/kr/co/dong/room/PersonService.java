package kr.co.dong.room;

import java.util.List;

public interface PersonService {

	public List<PersonBean> listAll();

	public int insert(PersonBean rb);

	public PersonBean selectOne(String name);

	public int update(PersonBean rb);

	public int delete(String name);

}
