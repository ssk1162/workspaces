package kr.co.dong.jdbc.copy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class test2 {
	
	public static void main(String[] args) {
		
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("�����ȣ �Է��ؼ� �̸� �˻� : ");
		int empno = Integer.parseInt(sc.nextLine());
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url = "jdbc:mysql://localhost/scott?characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false";
			String id = "root";
			String pw = "12345";
			
			con = DriverManager.getConnection(url, id, pw);
			System.out.println("���� ����");
			
			String sql = "select empno, ename from emp where empno = ?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, empno);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				System.out.println(rs.getString(1) + " : " + rs.getString(2));
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	
}
