package kr.co.dong.jdbc.copy;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class test3 {
	
	public static void main(String[] args) {
		
		Connection con = null;
		Scanner sc = new Scanner(System.in);
		PreparedStatement ps = null;
		
		System.out.print("�����ȣ �Է� (7xxx): ");
		int empno = Integer.parseInt(sc.nextLine());
		System.out.print("����̸� �Է� : ");
		String ename = sc.nextLine();
		System.out.print("���� : ");
		String job = sc.nextLine();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url = "jdbc:mysql://localhost/scott?characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false";
			String id = "root";
			String pw = "12345";
			
			con = DriverManager.getConnection(url, id, pw);
			System.out.println("���� ����");
			
			String sql = "insert into emp (empno, ename, job) ";
				   sql += "values (?,?,?)";
			
			ps = con.prepareStatement(sql);
			ps.setInt(1, empno);
			ps.setString(2, ename);
			ps.setString(3, job);
			
			ps.executeUpdate();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	
}
