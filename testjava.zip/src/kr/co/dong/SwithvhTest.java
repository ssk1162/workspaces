package kr.co.dong;

import java.util.Scanner;

public class SwithvhTest {
	public static void main(String[] args) {

		int num = 10;

		switch (num) {
		case 10:
			numSu2(); // ȣ��
			break;
		case 20:
			System.out.println("bb");
			break;
		case 30:
			System.out.println("cc");
			break;
		default:
			System.out.println("dd");
			break;
		}

		
	}

	private static void numSu2() { // private ���⼭�� ȣ�� ���� / static �޸𸮷� �ٷ�
		System.out.println("ddddddddddddddddd");
		System.out.println("aa");
		System.out.println("aa");
		System.out.println("aa");
		System.out.println("aa");
		System.out.println("aa");
		System.out.println("aa");
		System.out.println("aa");
		System.out.println("���� ����");

	}

}
