package kr.co.dong;

public class WhileTest02 {
	public static void main(String[] args) {

//		1~10���� �� ���ϱ�

		int sum = 0;
		int num = 1;
		
		while (num <= 10) {
			sum += num;
			num++;
		}
		System.out.println(sum);

//		for (int i = 1; i <= 10; i++) {
//
//			sum += i;
//
//		}
//		System.out.println(sum);

	}
}
