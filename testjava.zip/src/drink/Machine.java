package drink;

/*
 * ����, ����, ����
 */
public class Machine { // ����ü

	private String rGoods;
	private int pay;
	private int rGoodsNum;
			
	public Machine(String rGoods, int pay, int rGoodsNum) {
		super();
		this.rGoods = rGoods;
		this.pay = pay;
		this.rGoodsNum = rGoodsNum;
	}

	public String getrGoods() {
		return rGoods;
	}

	public void setrGoods(String rGoods) {
		this.rGoods = rGoods;
	}

	public int getPay() {
		return pay;
	}

	public void setPay(int pay) {
		this.pay = pay;
	}

	public int getrGoodsNum() {
		return rGoodsNum;
	}

	public void setrGoodsNum(int rGoodsNum) {
		this.rGoodsNum = rGoodsNum;
	}

	@Override
	public String toString() {
		return rGoods + " / ���� : " + pay + " / ��ǰ ��� : " + rGoodsNum;
	}

}
