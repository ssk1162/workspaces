package drink;

import java.util.Scanner;

public class MachineAble {
	Scanner sc = new Scanner(System.in);
	MacView mv = null;

	void menuview() {
		mv = new MacView();
		for (Machine m : mv.list) {
			System.out.println(m);
		}
	}

	void selMenu(String menu, MacView mv) { // ��ǰ ����
		int num = searchMenu(menu, mv);
		
		if (num != -1) {
			System.out.println(mv.list.get(num).getrGoods() + " ��ǰ ����");
		} else {
			System.out.println("��ǰ�� Ȯ���� �� �����ϴ�");
		}

	}

	int searchMenu(String rMenu, MacView mv) {
		int idx = -1;

		for (int i = 0; i < mv.list.size(); i++) {
			if (rMenu.equals(mv.list.get(i).getrGoods())) {
				idx = i;
				break;
			}
		}
		return idx;
	}

	String selectmsg(String msg) {
		System.out.print(msg + " : ");
		return sc.next();
	}

	int selectmsg2(String msg) {
		System.out.print(msg + " : ");
		return sc.nextInt();
	}
}
