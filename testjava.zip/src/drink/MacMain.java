package drink;

import java.util.Iterator;
import java.util.Scanner;

public class MacMain {

	public static void main(String[] args) {
		boolean power = false;
		Scanner sc = new Scanner(System.in);
		MacView mv = new MacView();
		MachineAble ma = new MachineAble();
		CustomerAble ca = new CustomerAble();

		mv.init();

		while (!power) {
			System.out.println("1) ��ǰ����, 2) �ݾ�����, 3) ����");
			int menu = ma.selectmsg2("��ȣ ����");
			switch (menu) {
			case 1:
				ma.menuview();
				Iterator<Machine> rator = mv.list.iterator();
				while (rator.hasNext()) {
					System.out.println(rator.next());
				}
				System.out.print("��ǰ �Է� : ");
				String name = sc.next();
				ma.selMenu(name, mv);
				break;
				
			case 2:
				ca.charge();
				System.out.println(ca);
				break;
				
			case 3:
				System.out.print("����");
				System.exit(0);
				break;
			}
		}
	}
}
