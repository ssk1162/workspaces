package drink;

/*
 * ���, ��
 */
public class Customer {

	private String rcust;
	private int money;

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public String getRcust() {
		return rcust;
	}

	public void setRcust(String rcust) {
		this.rcust = rcust;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	@Override
	public String toString() {
		return "Customer [rcust=" + rcust + ", money=" + money + "]";
	}

}
