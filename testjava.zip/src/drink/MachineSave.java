package drink;

import java.util.ArrayList;
import java.util.List;

public class MachineSave {
	
	List<Machine> savemachine = new ArrayList<Machine>();
	
	public void addSavemachine (Machine machine) {
		savemachine.add(new Machine(machine.getrGoods(), machine.getPay(), machine.getrGoodsNum()));
		System.out.println(machine.getrGoods() + " ��ǰ ����");
	}
	
}
