package testtest;

public class TestTest {
	
	public void isEven(int num) {
		if(num % 2 == 0) {
			System.out.println("true");
		} else {
			System.out.println("false");			
		}
	}

	public void isOdd(int num) {
		if(num % 2 == 0) {
			System.out.println("false");			
		} else {
			System.out.println("true");
		}
	}
	
	public void isMulti(int num) {
		if(num % 2 == 0) {
			System.out.println("true");
		} else {
			System.out.println("false");			
		}
	}
	
	public void isMulti2(int num, int num2) {
		if(num % 3 == 0 && num2 % 3 == 0) {
			System.out.println("true");
		} else {
			System.out.println("false");			
		}
	}
	
	public void isMulti3(int num, int num2) {
		if(num % 5 == 0 && num2 % 5 == 0) {
			System.out.println("true");
		} else {
			System.out.println("false");			
		}
	}
	
	public void isMulti4(int num, int num2) {
		if(num > num2) {
			System.out.println(num);
		} else if (num < num2) {
			System.out.println(num2);			
		}
	}
	
	int arr[] = {1,7,9,3,8};
	public void max(int arr[]) {
		int max = arr[0];
		for (int i = 0; i < arr.length; i++) {
			max = arr[i];
		}
		System.out.println(max);
	}
	
	public void isMulti5(int num, int num2) {
		if(num < num2) {
			System.out.println(num);
		} else if (num > num2) {
			System.out.println(num2);			
		}
	}
}
