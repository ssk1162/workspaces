package testtest;

public class TestTest2 {

	public static void main(String[] args) {

		TestTest tt = new TestTest();

		tt.isEven(10);
		tt.isEven(11);

		tt.isOdd(10);
		tt.isOdd(11);

		tt.isMulti(10);
		tt.isMulti(15);

		tt.isMulti2(10, 3);
		tt.isMulti2(15, 3);

		tt.isMulti3(10, 5);
		tt.isMulti3(15, 5);

		tt.isMulti4(10, 20);
		tt.isMulti4(20, 5);

	}
}
