package vendingMahchine;

public class Manager {
	private int pwd = 4444;

	public int getPwd() {
		return pwd;
	}

	public void setPwd(int pwd) {
		this.pwd = pwd;
	}
}
