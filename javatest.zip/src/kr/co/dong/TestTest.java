package kr.co.dong;

public class TestTest {

	public static void main(String[] args) {

		int x = 2;
		int y = 5;
		char c = 'A';

		System.out.println(1 + x << 33);
		System.out.println(y >= 5 || x < 0 && x > 2);
		System.out.println(y += 10 - x++);
		System.out.println(x += 2);
		System.out.println(!('A' <= c && c <= 'Z'));
		System.out.println('C' - c);
		System.out.println('5' - '0');
		System.out.println(c + 1);
		System.out.println(++c);
		System.out.println(c++);
		System.out.println(c);

		System.out.println();

		int numOfApples = 123;
		int sizeOfBucket = 10;
//		int numOfBucket = (int) Math.ceil((double)numOfApples / sizeOfBucket);
		int numOfBucket = 0;

		numOfBucket = numOfApples / sizeOfBucket; // + (numOfApples / sizeOfBucket > 0 ? 1 : 0);

		if (numOfApples % sizeOfBucket > 0) { // ���� ����� �ִٸ�
			numOfBucket++; // 1�߰�
		}
		System.out.println(numOfBucket);

//		System.out.println((double)numOfApples);
//		System.out.println((double)numOfApples / sizeOfBucket);
//		System.out.println(numOfBucket);

		System.out.println();

		int num = 10;
		String str = null;

		str = (num > 0 ? "���" : (num < 0 ? "����" : "0"));

		System.out.println(str);

		System.out.println(num >= 0 ? (num == 0 ? "0" : "���") : "����");

		System.out.println();

		int num2 = 456;

		System.out.println(num2 / 100 * 100);
		System.out.println();

		int num3 = 322;
		System.out.println(num3 / 10 * 10 + 1);
		System.out.println();

		int num4 = 81;

		System.out.println((num4 / 10 + 1) * 10 % num4);
		System.out.println(10 - num4 % 10);

		int fahrenheit = 100;
		float celcius = (int) (5 / 9f * (fahrenheit - 32) * 100 + 0.5) / 100f;

		System.out.println(fahrenheit);
		System.out.println(celcius);
		System.out.println();

		byte a = 10;
		byte b = 20;
		byte cc = (byte) (a + b);

		char ch = 'A';
		ch = (char) (ch + 2);

		float f = 3 / 2f;
		long l = 3000 * 3000 * 3000L;

		float f2 = 0.1f;
		double d = 0.1;

		boolean result = (float) d == f2;

		System.out.println(cc);
		System.out.println(ch);
		System.out.println(f);
		System.out.println(l);
		System.out.println(result);
		System.out.println();

		char ch2 = 'z';
		boolean b2 = (ch2 >= 'A' && ch2 <= 'Z') || (ch2 >= 'a' && ch2 <= 'z') || (ch2 >= '1' && ch2 <= '9');
		// ����ǥ����
		// ex = ^[A-Za-Z0-9]
		// ^[��-��] ^[0-9]
		System.out.println(b2);
		System.out.println();

		char ch3 = '1';

		char lowerCase = (ch3 >= 'A' && ch <= 'Z') ? (char) (ch3 + 32) : ch3;

		System.out.println(ch3);
		System.out.println(lowerCase);

	}

}
