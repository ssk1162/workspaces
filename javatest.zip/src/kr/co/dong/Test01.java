package kr.co.dong;

public class Test01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Ctrl + F11 = �ܼ� ���� ���� ����Ű
		
		// Ctrl + alt + ����Ű (����) = ����
		
		// Alt + ����Ű (����) = �̵�
		
		// Ctrl + space bar = �ڵ��ϼ� ȣ��
		
		// ���ڶ� ���ڿ��̶� �������� �˾ƾ��� ������ 123�̶� ���ڿ� "123"�̶� �� �ٸ�
		
		System.out.println("                       .-.");
		System.out.println("                      |_:_|");
		System.out.println("                     /(_Y_)\\");
		System.out.println(".                   ( \\/M\\/ )");
		System.out.println(" '.               _.'-/'-'\\-'");
		System.out.println("   ':           _/.--'[[[[]'--.\\");
		System.out.println("     ':        /_'  : |::\"| :  '.\\");
		System.out.println("       ':     //   ./ |oUU| \\.'  :\\");
		System.out.println("         ':  _:'..' \\_|___|_/ :   :|");
		System.out.println("           ':.  .'  |_[___]_|  :.':\\");
		System.out.println("            [::\\ |  :  | |  :   ; : \\");
		System.out.println("             '-'   \\/'.| |.' \\  .;.' |");
		System.out.println("             |\\_    \\  '-'   :       |");
		System.out.println("             |  \\    \\ .:    :   |   |");
		System.out.println("             |   \\    | '.   :    \\  |");
		System.out.println("              /       \\   :. .;       |");
		System.out.println("            /     |   |  :__/     :  \\\\");
		System.out.println("           |  |   |    \\:   | \\   |   ||");
		System.out.println("          /    \\  : :  |:   /  |__|   /|");
		System.out.println("      snd |     : : :_/_|  /'._\\  '--|_\\");
		System.out.println("          /___.-/_|-'   \\  \\");
		System.out.println("                         '-'");
		System.out.println("Art by Shanaka Dias");
	}

}
