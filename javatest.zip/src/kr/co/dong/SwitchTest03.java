package kr.co.dong;

import java.util.Scanner;

public class SwitchTest03 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int a = sc.nextInt();
		int b = (int) (Math.random() * 3) + 1;
		// 1 ����
		// 2 ����
		// 3 ��
		System.out.println(a);
		System.out.println(b);
		
		switch (a) {
		case 1:
			if (b == 1) {
				System.out.println("����");
			} else if (b == 2){
				System.out.println("����");
			} else {
				System.out.println("�̰��");
			}
			break;
		case 2:
			if (b == 2) {
				System.out.println("����");
			} else if (b == 1){
				System.out.println("dl���");
			} else {
				System.out.println("wuT��");
				
			}
			break;
		default:
			if (b == 3) {
				System.out.println("����");
			} else if (b == 2){
				System.out.println("dl���");
			} else {
				System.out.println("wuT��");
				
			}
			break;
		}

//		int c = 0;
//		String d = null;

//		c = a * 10 + b;

//		switch (c) {
//		case 23:
//		case 12:
//		case 13:
//			d = "����";
//			break;
//		case 21:
//		case 31:
//		case 32:
//			d = "�̰��";
//			break;
//
//		default:
//			d = "����";
//			break;
//
//		}
//		System.out.println(a + " " + b + " " + d);

	}
}
