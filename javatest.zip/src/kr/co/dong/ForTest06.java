package kr.co.dong;

public class ForTest06 {

	public static void main(String[] args) {

//		1���� 10������ �� ���Ѵ�
//		�� ������� " 1 + 2 ~~ = 55 "

		int[] a = new int[10];
		int sum = 0;
		char buho = '+';

		for (int i = 1; i <= 10; i++) {
			sum += i;
			if (i < 10) {
				buho = '+';
			} else {
				buho = '=';
			}
			System.out.print(i + "" + buho);
		}
		System.out.println(sum);

//		for (int i = 1; i <= a.length; i++) {	//1 <= 10
//						
//			a[i-1] = i;							
//			
//			System.out.print(a[i-1]);			//1 ~ 10 ���
//			
//			if (a[i-1] < a.length) {			//1 ~ 10 < 10�̸��̸� +
//				System.out.print(buho);			//+
//			}
//			sum += a[i-1];						//1 + ~~ 10  55
//			
//		}
//		System.out.println(" = "+ sum);			//10 = ��55

	}

}
