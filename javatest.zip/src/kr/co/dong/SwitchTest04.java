package kr.co.dong;

import java.util.Scanner;

public class SwitchTest04 {
	public static void main(String[] args) {
//		if������ ó���� ����ó���� switch������ ó���غ���

		int score = 0;

		Scanner sc = new Scanner(System.in);
		char grade = 'x';
		char buho = '0';
		int x = 0;
		System.out.print("�����Է� : ");

		score = sc.nextInt();

		x = score / 10;

		switch (x) {
		case 10:
			grade = 'A';
			break;
		case 9:
		case 8:
			grade = 'B';
			break;
		case 7:
		case 6:
			grade = 'C';
			break;
		default:
			if (x >= 4) {
				grade = 'D';
			} else {
				System.out.println("���� �̴�");
			}
			break;
		}
		if (score >= 60) {
			buho = '+';
		} else {
			buho = '-';

		}

		System.out.println(score + "" + buho + " " + grade + "���");

		sc.close();

//		System.out.print("�ֹι�ȣ �Է� > ");
//		
//		Scanner sc = new Scanner(System.in);
//		
//		String a = sc.nextLine();
//		
//		char g = a.charAt(7);
//		
//		switch (g) {
//		case '1':
//		case '3':
//			System.out.println("����");
//			break;
//		case '2':
//		case '4':
//			System.out.println("����");
//			break;
//		default:
//			System.out.println("�ٽ� �Է�");
//			break;
//		}

//		if (g == '1' || g == '3') {
//			System.out.println("m");
//			System.out.println(g);
//		} else if (g == '2' || g == '4') {
//			System.out.println("g");
//		} else {
//			System.out.println("�ٽ�");
//			System.out.println(g);
//		}

	}
}
