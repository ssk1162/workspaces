package kr.co.dong;

public class StringTest01 {
	public static void main(String[] args) {

		String str = "Do Not Slpping";
		
		char ch = str.charAt(0);
		System.out.println(str.charAt(0));
		System.out.println(str.charAt(1));

//		���ڿ��� ����
		int len = str.length();

		System.out.println(len);

		for (int i = 0; i < len; i++) {

			System.out.print(str.charAt(i));

		}
		System.out.println();
		
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			System.out.println(c);

		}
		
		System.out.println(str.contains("a"));
		System.out.println(str.indexOf('S'));
		System.out.println(str.valueOf('S'));
		
	}
}
