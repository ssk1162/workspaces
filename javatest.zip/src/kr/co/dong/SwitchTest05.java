package kr.co.dong;

import java.util.Scanner;

public class SwitchTest05 {
	public static void main(String[] args) {

		char g = ' ';
		int s = 0;

		System.out.print("���� �Է�");
		Scanner sc = new Scanner(System.in);
		String s2 = sc.nextLine();
		s = Integer.parseInt(s2);

		switch (s / 10) {
		case 10:
		case 9:
			g = 'A';
			break;
		case 8:
		case 7:
			g = 'B';
			break;
		case 6:
		case 5:
			g = 'C';
			break;
		default:
			g = 'F';
			break;
		}
		System.out.println(s + " " + g);

	}
}
