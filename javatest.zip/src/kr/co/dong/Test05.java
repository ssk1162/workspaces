package kr.co.dong;

public class Test05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String str1 = "Hello";
		String str2 = "JAVA";

		String str3 = str1 + str2; // "HelloJAVA"
		
		
		System.out.println(str3);
		
		
	}

}
