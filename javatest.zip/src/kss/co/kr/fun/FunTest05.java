package kss.co.kr.fun;

/*
 * Ư�����ڿ� Ƚ�� �Է¹޾Ƽ� �� Ƚ����ŭ �ݺ� ���
 * printView(10,"$");
 * > "$$$$$$$$$$"
 * printView(3, "&");
 * > "&&&"
 */

public class FunTest05 {
	public static void main(String[] args) {

		printView(10,"$");
		printView(3, "&");
		printView(5, "*");
		
	}

	static void printView(int n, String n2) {
		for (int i = 0; i < n; i++) {
			System.out.print(n2);
		}
		System.out.println();
	}
}
