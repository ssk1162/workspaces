package kss.co.kr.ch06;

public class CheckTest {
	public static void main(String[] args) {
		
		CheckingAccount ca = new CheckingAccount();
		ca.accountNum = "123-123-1234";
		ca.balance = 200000;
		ca.cardNo = "123-123";
		
//		����ī��� 3������ ����
		int tmp;
		try {
			tmp = ca.pay("123-231", 30000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		System.out.println(tmp);
		System.out.println("end");
		
	}
}
