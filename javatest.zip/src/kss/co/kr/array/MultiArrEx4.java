package kss.co.kr.array;

import java.util.Scanner;

public class MultiArrEx4 {
	public static void main(String[] args) {
		
		String[][] words = {
				{ "chair", "����" },
				{ "computer", "��ǻ��" },
				{ "Intger", "����" }
		};
		
		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < words.length; i++) {
			System.out.print("Q" + (i + 1) + ". " + words[i][0] + "�� �����ΰ� >> ");
			
			String tmp = sc.next();
			
			if (tmp.equals(words[i][1])) {
				System.out.println("�����̴�");
			} else {
				System.out.println("Ʋ�ȴ� " + words[i][1] + "��");
			}
			
		}
		
	}
}
