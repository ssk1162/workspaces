package kss.co.kr.array;

import javax.swing.JOptionPane;

public class ArrayTest19 {
	public static void main(String[] args) {

		String name = JOptionPane.showInputDialog("���� �̸��� : ");
		System.out.println(name);
//		int name2 = Integer.parseInt(name);
//		System.out.println(name2);
		
	}
}
