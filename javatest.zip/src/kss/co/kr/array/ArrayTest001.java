package kss.co.kr.array;

import java.util.Iterator;

public class ArrayTest001 {
	public static void main(String[] args) {
		
		int[] num = new int[10];
		int sum = 0;
		int sum2 = 0;
		int max = 0;
		int min = 101;
		
		
		for (int i = 0; i < num.length; i++) {
			num[i] = (int)(Math.random() * 100) + 1;
			System.out.print(num[i] + ", ");
		}
		
		for (int i = 0; i < num.length; i++) {
			sum += num[i];
			System.out.print(num[i]);			
		}
		System.out.println();
		
		
		System.out.println(sum);
		
		for (int i = 0; i < num.length; i++) {

			if (max < num[i]) {
				max = num[i];
			}
			
			if (min > num[i]) {
				min = num[i];
			}
			sum2 = max + min;
		}
		
		System.out.println();
		System.out.println("�ּ� " + min + " �ִ� " + max + " �� " + sum2);
		
		
		
		
	}
}
