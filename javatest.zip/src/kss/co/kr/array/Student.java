package kss.co.kr.array;

public class Student {
	
		String name;
		String hobby;
		String blood;
		int age;
		
}
