package kr.co.test;

import java.util.Iterator;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import kr.co.test.board.BoardDAO;
import kr.co.test.board.BoardDTO;
import kr.co.test.controller.Criteria;
import kr.co.test.controller.SearchCriteria;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})
public class TableCreateTest {
	
	private final static Logger logger = LoggerFactory.getLogger(TableCreateTest.class);
	
	@Autowired
	BoardDAO dao;
	
//	@Test
//	public void testPaging() throws Exception {
//		
//		int page = 3;
//		
//		List<BoardDTO> list = dao.listPage(page);
//		logger.info("list : " + list);
//		
//		for (BoardDTO tabledto : list) {
//			logger.info(tabledto.getBno() + " : " + tabledto.getTitle());
//		}
//		
//	}
	
	@Test
	public void testListCriteria() throws Exception {
		SearchCriteria cri = new SearchCriteria();
		cri.setPage(2);
		cri.setKeyword("title");
		cri.setSearchType("t");
		
		logger.info("==================================");
		
		List<BoardDTO> list = dao.listSearch(cri);
		
		for(BoardDTO tabledto : list) {
			logger.info(tabledto.getBno() + " : " + tabledto.getTitle());
		}
		
		logger.info("==================================");
		
		logger.info("Count : " + dao.listSearchCount(cri));
		
	}

	
	
	
	
//	// 게시판 글쓰기 100개 해보기(DAO insert Test)
//	@Inject
//	private TableDAO tableDAO;
//	
//	@Test
//	public void insert() throws Exception {
//		
//		TableDTO tableDTO;
//		for (int i = 1; i <= 100; i++) {
//			tableDTO = new TableDTO();
//			tableDTO.setTitle("Test title [" + i + "]");
//			tableDTO.setContent("Test Content : " + i);
//			tableDTO.setId("root");
//			
//			tableDAO.insert(tableDTO);
//			
//			Thread.sleep(1000); // 1초 재우기
//			
//			
//			
//		}
//		
//		
//	}
	
	
	
	
	
}
