package kr.co.test;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.co.test.board.BoardDAO;
import kr.co.test.board.BoardDTO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})
public class BoardCreateTest {
	
	// 게시판 글쓰기 1000개 해보기(DAO insert Test)
	@Inject
	private BoardDAO boardDAO;
	
	@Test
	public void testinsert() throws Exception {
		
		BoardDTO boardDTO;
		for (int i = 1; i <= 100; i++) {
			boardDTO = new BoardDTO();
			boardDTO.setTitle("Test title [" + i + "]");
			boardDTO.setContent("Test Content : " + i);
			boardDTO.setId("root");
			
			boardDAO.insert(boardDTO);
			
			Thread.sleep(1000); // 1초 재우기
			
			
			
		}
		
		
	}
	
	
	
	
	
}
