package kr.co.test;

import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import kr.co.test.emp.EmpBean;
import kr.co.test.service.EmpService;

@Controller
public class SelectController {
	
	private static final Logger logger = LoggerFactory.getLogger(SelectController.class);
	
	@Inject
	private EmpService service;
	
	@GetMapping(value="/listAll")
	public ModelAndView listAll() {
		List<EmpBean> list = service.list();
		ModelAndView mav = new ModelAndView();
		mav.addObject("list", list);
		mav.setViewName("emplistAll");
		return mav;
	}
	
	@GetMapping(value="/selectOne")
	public ModelAndView selectOne(@RequestParam("empno") int empno) {
		EmpBean eb = service.selectOne(empno);
		ModelAndView mav = new ModelAndView();
		mav.addObject("listOne", eb);
		mav.setViewName("emplistOne");
		return mav;
	}
	
	@GetMapping(value="/insert")
	public String insert() {
		return "insertForm";
	}
	
	@PostMapping(value="/insert")
	public ModelAndView insert2(@ModelAttribute("info") EmpBean eb) {
		ModelAndView mav = new ModelAndView();
		logger.info("eb : " + eb);
		int num = service.insert(eb);
		List<EmpBean> list = service.list();
		mav.addObject("list", list);
		if (num != 1) {
			logger.info("생성 실패");
			mav.addObject("b", "생성 실패");
		} else {
			mav.addObject("a", "생성 완료");
			logger.info("생성 성공");
		}
		mav.setViewName("emplistAll");
		
		return mav;
	}
	
}
