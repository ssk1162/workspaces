package kr.co.test.board;

import java.util.List;
import java.util.Map;

import kr.co.test.controller.Criteria;
import kr.co.test.controller.SearchCriteria;

public interface BoardService {
	// 로그인 처리를 위한 메소드
	
		public Map login(Map<String, Object> map);
		
		public List<BoardDTO> listAll();
		public BoardDTO selectOne(int bno);
		public int update(BoardDTO bd);
		public int insert(BoardDTO bd);
		public int delete(int bno);
		public int updatecnt(int bno);
		
		// 게시물번호에 해당하는 댓글 조회
		public List<BoardReply> detail1(int bno);
		// 댓글 수정보기를 위한 메소드
		public BoardReply detailReply(int reno);
		// 댓글 쓰기를 위한 메소드
		public int reply(BoardReply br);
		// 댓글 수정 메소드
		public int replyupdate(BoardReply br);
		// 댓글 삭제 메소드
		public int replydelete(int reno);
		
		
		
		public List<BoardDTO> listPage(int page) throws Exception;

		public List<BoardDTO> listCriteria(Criteria cri) throws Exception;
		
		public List<BoardDTO> listSearchCriteria(SearchCriteria cri) throws Exception;
		
		public int listSearchCount(SearchCriteria cri) throws Exception;
		
		public int countPaging(Criteria cri) throws Exception;
		
		public int listCountCriteria(Criteria cri) throws Exception;
		
}
