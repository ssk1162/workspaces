package kr.co.test.board;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.test.controller.Criteria;
import kr.co.test.controller.SearchCriteria;

@Repository
public class BoardDAOImpl implements BoardDAO {

	@Autowired
	private SqlSession sqlsession;
	
	private final static String namespace = "kr.co.test.boardMapper";
	
	@Override
	public Map login(Map<String, Object> map) {
		return sqlsession.selectOne(namespace + ".login", map);
	}

	@Override
	public List<BoardDTO> listAll() {
		return sqlsession.selectList(namespace + ".listAll");
	}

	@Override
	public BoardDTO selectOne(int bno) {
		return sqlsession.selectOne(namespace + ".selectOne", bno);
	}

	@Override
	public int update(BoardDTO bd) {
		return sqlsession.update(namespace + ".update", bd);
	}

	@Override
	public int insert(BoardDTO bd) {
		return sqlsession.insert(namespace + ".insert", bd);
	}

	@Override
	public int delete(int bno) {
		return 0;
	}

	@Override
	public int updatecnt(int bno) {
		return sqlsession.update(namespace + ".updatecnt", bno);
	}

	@Override
	public List<BoardReply> detail1(int bno) {
		// TODO Auto-generated method stub
		return sqlsession.selectList(namespace + ".detail1", bno);
	}

	@Override
	public BoardReply detailReply(int reno) {
		// TODO Auto-generated method stub
		return sqlsession.selectOne(namespace + ".detailReply", reno);
	}

	@Override
	public int reply(BoardReply br) {
		// TODO Auto-generated method stub
		return sqlsession.insert(namespace + ".reply", br);
	}

	@Override
	public int replyupdate(BoardReply br) {
		// TODO Auto-generated method stub
		return sqlsession.update(namespace + ".replyUpdate", br);
	}

	@Override
	public int replydelete(int reno) {
		// TODO Auto-generated method stub
		return sqlsession.delete(namespace + ".replyDelete", reno);
	}

	@Override
	public List<BoardDTO> listPage(int page) throws Exception {
		
		if (page <= 0) {
			page = 1;
			System.out.println("1 : " + page);
		}
		
		page = (page - 1) * 10;
		System.out.println("2 : " + page);
		
		
		return sqlsession.selectList(namespace + ".listPage", page);
	}

	@Override
	public List<BoardDTO> listCriteria(Criteria cri) throws Exception {
		return sqlsession.selectList(namespace + ".listCriteria", cri);
	}

	@Override
	public int countPaging(Criteria cri) throws Exception {
		return sqlsession.selectOne(namespace + ".countPaging", cri);
	}

	@Override
	public List<BoardDTO> listSearch(SearchCriteria cri) throws Exception {
		return sqlsession.selectList(namespace + ".listSearch", cri);
	}

	@Override
	public int listSearchCount(SearchCriteria cri) throws Exception {
		return sqlsession.selectOne(namespace + ".listSearchCount" , cri);
	}
	
	
	
}
