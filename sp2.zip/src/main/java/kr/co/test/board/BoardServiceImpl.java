package kr.co.test.board;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.test.controller.Criteria;
import kr.co.test.controller.SearchCriteria;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private BoardDAO dao;
	
	@Override
	public Map login(Map<String, Object> map) {
		return dao.login(map);
	}

	@Override
	public List<BoardDTO> listAll() {
		return dao.listAll();
	}

	@Override
	public BoardDTO selectOne(int bno) {
		return dao.selectOne(bno);
	}

	@Override
	public int update(BoardDTO bd) {
		return dao.update(bd);
	}

	@Override
	public int insert(BoardDTO bd) {
		return dao.insert(bd);
	}

	@Override
	public int delete(int bno) {
		return 0;
	}

	@Override
	public int updatecnt(int bno) {
		return dao.updatecnt(bno);
	}

	
	
	@Override
	public List<BoardReply> detail1(int bno) {
		// TODO Auto-generated method stub
		return dao.detail1(bno);
	}

	@Override
	public BoardReply detailReply(int reno) {
		// TODO Auto-generated method stub
		return dao.detailReply(reno);
	}

	@Override
	public int reply(BoardReply br) {
		// TODO Auto-generated method stub
		return dao.reply(br);
	}

	@Override
	public int replyupdate(BoardReply br) {
		// TODO Auto-generated method stub
		return dao.replyupdate(br);
	}

	@Override
	public int replydelete(int reno) {
		// TODO Auto-generated method stub
		return dao.replydelete(reno);
	}

	@Override
	public List<BoardDTO> listPage(int page) throws Exception {
		return dao.listPage(page);
	}

	@Override
	public List<BoardDTO> listCriteria(Criteria cri) throws Exception {
		return dao.listCriteria(cri);
	}

	@Override
	public int countPaging(Criteria cri) throws Exception {
		return dao.countPaging(cri);
	}

	@Override
	public int listCountCriteria(Criteria cri) throws Exception {
		return dao.countPaging(cri);
	}

	@Override
	public List<BoardDTO> listSearchCriteria(SearchCriteria cri) throws Exception {
		return dao.listSearch(cri);
	}

	@Override
	public int listSearchCount(SearchCriteria cri) throws Exception {
		return dao.listSearchCount(cri);
	}
	
	
	
}
