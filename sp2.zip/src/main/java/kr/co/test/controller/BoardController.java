package kr.co.test.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import kr.co.test.board.BoardDTO;
import kr.co.test.board.BoardReply;
import kr.co.test.board.BoardService;

@Controller
public class BoardController {

	private final static Logger logger = LoggerFactory.getLogger(BoardController.class);

	@Autowired
	private BoardService service;

	@GetMapping("/board/login")
	public String login() {
		logger.info("로그인폼으로 이동");
		return "login";
	}

	@PostMapping("/board/login")
	public String login(@RequestParam Map<String, Object> map, HttpSession session, HttpServletRequest request)
			throws Exception {
		request.setCharacterEncoding("utf-8");
		logger.info("데이터베이스 전송");
		Map user = service.login(map);

		if (user == null) { // 로그인 실패
			return "redirect:/login";
		} else { // 로그인 성공
			session.setAttribute("user", user);
			return "redirect:/index";
		}

	}

	@GetMapping("/board/logout")
	public String logout(HttpSession session) {
		session.invalidate();

		return "redirect:/index";
	}

	@GetMapping(value = "/board/listPage")
	public ModelAndView list(Criteria cri) throws Exception {
		ModelAndView mav = new ModelAndView();
		
		logger.info(cri.toString());
		
		mav.addObject("list", service.listCriteria(cri));
		
		PageMaker pageMaker = new PageMaker();
		
		pageMaker.setCri(cri);
		
		pageMaker.setTotalCount(service.listCountCriteria(cri));
		
		mav.addObject("pageMaker", pageMaker);
		
		mav.setViewName("listPage");

		return mav;
	}

	@GetMapping(value = "/board/register")
	public String register() {
		return "register";
	}

	@PostMapping(value = "/board/register")
	public ModelAndView register(@ModelAttribute("info") BoardDTO dto, HttpSession session, HttpServletRequest request)
			throws Exception {
		request.setCharacterEncoding("utf-8");
		ModelAndView mav = new ModelAndView();
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd a hh:mm:ss");
		dto.setRegdate(df.format(date));
		Map user = (Map) session.getAttribute("user");
		String name = (String) user.get("id");
		dto.setId(name);
		int num = service.insert(dto);
		List<BoardDTO> list = service.listAll();
		if (num != 1) {
			logger.info("생성 실패");
			mav.setViewName("list");
		} else {
			logger.info("생성 성공");
			mav.addObject("list", list);
			mav.setViewName("list");
		}

		return mav;
	}

	@GetMapping(value = "/board/detail")
	public ModelAndView detail(@RequestParam("bno") int bno, BoardDTO dto) {
		service.updatecnt(bno);
		dto = service.selectOne(bno);
		logger.info(" dto : " + dto);
		ModelAndView mav = new ModelAndView();
		mav.addObject("board", dto);

		// 댓글 목록 조회
		List<BoardReply> replylist = service.detail1(bno);
		mav.addObject("list", replylist);

		mav.setViewName("detail");
		return mav;

	}
	

	@GetMapping(value = "/board/update")
	public ModelAndView update(@RequestParam("bno") int bno, BoardDTO dto, HttpSession session) {
		dto = service.selectOne(bno);
		ModelAndView mav = new ModelAndView();
		mav.addObject("board", dto);
		mav.setViewName("update");
		return mav;
	}

	@PostMapping(value = "/board/update")
	public ModelAndView update(@ModelAttribute("bd") BoardDTO bd) {
		ModelAndView mav = new ModelAndView();
		logger.info("dto : " + bd);
		service.update(bd);
		List<BoardDTO> list = service.listAll();
		mav.addObject("list", list);
		mav.setViewName("list");

		return mav;
	}

//	ajax 댓글에 대한 매핑과 메소드를 구현
//	"board/replylist" 매핑설정
//	글번호가 요청되어야함
//	json처리를 위한 라이브러리가 필요함 > jackson-datebind, jackson-core	
	@ResponseBody
	@PostMapping(value = "/board/replylist")
	public List<BoardReply> replylist(@RequestParam("bno") int bno) {
		return service.detail1(bno);
	}
	
	// 댓글 쓰기
	@ResponseBody
	@PostMapping(value="/board/reply2")
	public int reply2(BoardReply br) {
		return service.reply(br);
	}
	
	// 댓글 수정
	@ResponseBody
	@PostMapping(value="/board/replyupdate2")
	public Map<String, Object> replyupdate2(BoardReply br) {
		Map<String, Object> result = new HashMap<String, Object>();
		try {
			service.replyupdate(br);
			result.put("status", "OK");
			logger.info("result : " + result);
		} catch (Exception e) {
			e.printStackTrace();
			result.put("status", "Fail");
			logger.info("result" + result);
		}
		
		return result;
	}
	
	@ResponseBody
	@PostMapping(value="/board/replydelete2")
	public int replydate2(int reno) {
		return service.replydelete(reno);
	}
	
//	public int replyupdate2(BoardReply br) {
//		return service.replyupdate(br);
//	}
	
	
	
	
	
//	@GetMapping(value = "/listCri")
//	public void listAll(Criteria cri, Model model) throws Exception {
//
//		logger.info("show list Page with Criteria...............");
//
//		model.addAttribute("list", service.listCriteria(cri));
//
//	}

	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
