package kr.co.test.service;

import java.util.List;

import kr.co.test.emp.EmpBean;

public interface EmpService {
	
	public EmpBean selectOne(int empno);
	public List<EmpBean> list();
	public int insert(EmpBean eb);
	public int update(EmpBean eb);
	public int delete(String name);
	
	
}
