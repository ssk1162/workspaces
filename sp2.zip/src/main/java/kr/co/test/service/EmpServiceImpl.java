package kr.co.test.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import kr.co.test.dao.EmpDAO;
import kr.co.test.emp.EmpBean;

@Service
public class EmpServiceImpl implements EmpService {
	
	@Inject
	private EmpDAO dao;
	
	@Override
	public EmpBean selectOne(int empno) {
		return dao.selectOne(empno);
	}

	@Override
	public List<EmpBean> list() {
		return dao.list();
	}

	@Override
	public int insert(EmpBean eb) {
		System.out.println(eb);
		return dao.insert(eb);
	}

	@Override
	public int update(EmpBean eb) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(String name) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
}
