package kr.co.test.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import kr.co.test.emp.EmpBean;

@Repository
public class EmpDAOImpl implements EmpDAO {
	
	@Inject
	private SqlSession sqlsession;
	
	private final static String namespace = "kr.co.test.empMapper";
	
	@Override
	public EmpBean selectOne(int empno) {
		return sqlsession.selectOne(namespace + ".listOne", empno);
	}

	@Override
	public List<EmpBean> list() {
		return sqlsession.selectList(namespace + ".listAll");
	}

	@Override
	public int insert(EmpBean eb) {
		System.out.println(eb);
		return sqlsession.insert(namespace + ".insertOne", eb);
	}

	@Override
	public int update(EmpBean eb) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(String name) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
}
