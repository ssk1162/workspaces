package kr.co.kss;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class TableDAOImpl implements TableDAO {

	@Autowired
	private SqlSession sqlsession;

	private static final String namespace = "kr.co.kss.testmapper";

	@Override
	public List<TableDTO> list() {
		return sqlsession.selectList(namespace + ".listAll");
	}

	@Override
	public TableDTO selectone(int no) {
		return sqlsession.selectOne(namespace + ".selectone", no);
	}

	@Override
	public int update(TableDTO dto) {
		return 0;
	}

	@Override
	public int insert(TableDTO dto) {
		return sqlsession.insert(namespace + ".insert", dto);
	}

	@Override
	public int delete(int no) {
		return 0;
	}

	@Override
	public List<TableDTO> listPage(int page) {
		
		if (page <= 0) {
			page = 1;
			System.out.println("1 : " + page);
		}
		
		page = (page - 1) * 10;
		System.out.println("2 : " + page);
		
		
		return sqlsession.selectList(namespace + ".listPage", page);
	}

	@Override
	public List<TableDTO> listCriteria(Criteria cri) throws Exception {
		return sqlsession.selectList(namespace + ".listCriteria", cri);
	}

	@Override
	public int countPaging(Criteria cri) throws Exception {
		return sqlsession.selectOne(namespace + ".countPaging", cri);
	}

}
