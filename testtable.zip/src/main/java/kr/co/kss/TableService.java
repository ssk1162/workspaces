package kr.co.kss;

import java.util.List;

public interface TableService {
	
	public List<TableDTO> list();
	public TableDTO selectone(int no);
	public int update(TableDTO dto);
	public int insert(TableDTO dto);
	public int delete(int no);
	
	public List<TableDTO> listCriteria(Criteria cri) throws Exception;
	
	public int countPaging(Criteria cri) throws Exception;
	
}
