package kr.co.kss;

import java.util.List;
import java.util.Map;

public interface TableDAO {
	
	public List<TableDTO> list();
	public TableDTO selectone(int no);
	public int update(TableDTO dto);
	public int insert(TableDTO dto);
	public int delete(int no);
	
	public List<TableDTO> listPage(int page) throws Exception;

	public List<TableDTO> listCriteria(Criteria cri) throws Exception;
	
	public int countPaging(Criteria cri) throws Exception;
	
}
