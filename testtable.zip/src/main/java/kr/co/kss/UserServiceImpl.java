package kr.co.kss;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO dao;

	@Override
	public List<UserDTO> list() {
		return dao.list();
	}

	@Override
	public TableDTO selectone(int no) {
		return dao.selectone(no);
	}

	@Override
	public int update(UserDTO dto) {
		return 0;
	}

	@Override
	public int insert(UserDTO dto) {
		return 0;
	}

	@Override
	public int delete(int no) {
		return 0;
	}

	@Override
	public Map login(Map<String, Object> map) {
		return dao.login(map);
	}

}
