package kr.co.kss;

/*
u_no int AI PK 
u_id varchar(45) 
u_password varchar(45) 
u_nick varchar(45)
 */

public class UserDTO {
	private int u_no;
	private String u_id;
	private String u_password;
	private String u_nick;

	public int getU_no() {
		return u_no;
	}

	public void setU_no(int u_no) {
		this.u_no = u_no;
	}

	public String getU_id() {
		return u_id;
	}

	public void setU_id(String u_id) {
		this.u_id = u_id;
	}

	public String getU_password() {
		return u_password;
	}

	public void setU_password(String u_password) {
		this.u_password = u_password;
	}

	public String getU_nick() {
		return u_nick;
	}

	public void setU_nick(String u_nick) {
		this.u_nick = u_nick;
	}

	@Override
	public String toString() {
		return "UserDTO [u_no=" + u_no + ", u_id=" + u_id + ", u_password=" + u_password + ", u_nick=" + u_nick + "]";
	}

}
