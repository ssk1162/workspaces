package kr.co.kss;

/*
Table: table
Columns:
no int AI PK 
title varchar(45) 
content varchar(45) 
today varchar(45) 
up int
 */

public class TableDTO {

	private int no;
	private String title;
	private String content;
	private String today;
	private int up;
	private String id;

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getToday() {
		return today;
	}

	public void setToday(String today) {
		this.today = today;
	}

	public int getUp() {
		return up;
	}

	public void setUp(int up) {
		this.up = up;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "TableDTO [no=" + no + ", title=" + title + ", content=" + content + ", today=" + today + ", up=" + up
				+ ", id=" + id + "]";
	}

}
