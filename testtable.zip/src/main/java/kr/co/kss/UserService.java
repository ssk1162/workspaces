package kr.co.kss;

import java.util.List;
import java.util.Map;

public interface UserService {
	
	public Map login(Map<String, Object> map);
	
	public List<UserDTO> list();
	public TableDTO selectone(int no);
	public int update(UserDTO dto);
	public int insert(UserDTO dto);
	public int delete(int no);
		
}
