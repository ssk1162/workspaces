package kr.co.kss;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TableServiceImpl implements TableService {

	@Autowired
	private TableDAO dao;

	@Override
	public List<TableDTO> list() {
		return dao.list();
	}

	@Override
	public TableDTO selectone(int no) {
		return dao.selectone(no);
	}

	@Override
	public int update(TableDTO dto) {
		return 0;
	}

	@Override
	public int insert(TableDTO dto) {
		return 0;
	}

	@Override
	public int delete(int no) {
		return 0;
	}

	@Override
	public List<TableDTO> listCriteria(Criteria cri) throws Exception {
		return dao.listCriteria(cri);
	}

	@Override
	public int countPaging(Criteria cri) throws Exception {
		return dao.countPaging(cri);
	}

}
