package kr.co.kss;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDAOImpl implements UserDAO {

	@Autowired
	private SqlSession sqlsession;

	private static final String namespace = "kr.co.kss.testmapper";

	@Override
	public List<UserDTO> list() {
		return sqlsession.selectList(namespace + ".listAll");
	}

	@Override
	public TableDTO selectone(int no) {
		return sqlsession.selectOne(namespace + ".selectone", no);
	}

	@Override
	public int update(UserDTO dto) {
		return 0;
	}

	@Override
	public int insert(UserDTO dto) {
		return 0;
	}

	@Override
	public int delete(int no) {
		return 0;
	}

	@Override
	public Map login(Map<String, Object> map) {
		return sqlsession.selectOne(namespace + ".login", map);
	}

}
