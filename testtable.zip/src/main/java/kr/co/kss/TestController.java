package kr.co.kss;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TestController {

	@Autowired
	private UserService service;

	@Autowired
	private TableService tservice;

	private static final Logger logger = LoggerFactory.getLogger(TestController.class);

	@GetMapping(value = "/")
	public String index() {
		return "main";
	}

	@GetMapping(value = "/login")
	public String login(Model model) {
		logger.info("로그인 이동");
		List<TableDTO> list = tservice.list();

		model.addAttribute("list", list);

		return "index";
	}

	@GetMapping(value = "/naverLogin")
	public String naverLogin() {
		logger.info("네이버 로그인 이동");
		return "naverLogin";
	}

	@PostMapping(value = "/login")
	public String login(@RequestParam Map<String, Object> login, HttpSession session, Model model) {

		Map member = (Map) service.login(login);

		logger.info("login : " + login);
		logger.info("member : " + member);

		if (member != null) {
			session.setAttribute("member", member);
			Map nick = (Map) session.getAttribute("member");
			model.addAttribute("nick", nick);
			return "result";
		} else {
			return "index";
		}

	}

	@GetMapping(value = "/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

	@GetMapping(value = "/listCri")
	public void listAll(Criteria cri, Model model) throws Exception {

		logger.info("show list Page with Criteria...............");

		model.addAttribute("list", tservice.listCriteria(cri));

	}

	@GetMapping(value = "/listPage")
	public void listPage(Criteria cri, Model model) throws Exception {

		logger.info(cri.toString());

		List<TableDTO> list = tservice.listCriteria(cri);
		
		logger.info("list : " + list);

		model.addAttribute("list", tservice.listCriteria(cri));
		PageMaker pageMaker = new PageMaker();

		pageMaker.setCri(cri);
//		pageMaker.setTotalCount(131);

		pageMaker.setTotalCount(tservice.countPaging(cri));

		model.addAttribute("pageMaker", pageMaker);

	}
	
	@GetMapping(value = "/detail")
	public ModelAndView detail(@RequestParam("no") int no, TableDTO dto) {
//		service.updatecnt(no);
		dto = tservice.selectone(no);
		logger.info(" dto : " + dto);
		ModelAndView mav = new ModelAndView();
		mav.addObject("board", dto);

		// 댓글 목록 조회
//		List<BoardReply> replylist = service.detail1(bno);
//		mav.addObject("list", replylist);

		mav.setViewName("detail");
		return mav;

	}
	
	

}
