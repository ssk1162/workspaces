package kr.co.kss;

import java.util.Iterator;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})
public class TableCreateTest {
	
	private final static Logger logger = LoggerFactory.getLogger(TableCreateTest.class);
	
	@Autowired
	TableDAO dao;
	
//	@Test
//	public void testPaging() throws Exception {
//		
//		int page = 3;
//		
//		List<TableDTO> list = dao.listPage(page);
//		logger.info("list : " + list);
//		
//		for (TableDTO tabledto : list) {
//			logger.info(tabledto.getNo() + " : " + tabledto.getTitle());
//		}
//		
//	}
	
	@Test
	public void testListCriteria() throws Exception {
		Criteria cri = new Criteria();
		cri.setPage(2);
		cri.setPerPageNum(20);
		
		List<TableDTO> list = dao.listCriteria(cri);
		
		for(TableDTO tabledto : list) {
			logger.info(tabledto.getNo() + " : " + tabledto.getTitle());
		}
		
	}

	
	
	
	
//	// 게시판 글쓰기 100개 해보기(DAO insert Test)
//	@Inject
//	private TableDAO tableDAO;
//	
//	@Test
//	public void insert() throws Exception {
//		
//		TableDTO tableDTO;
//		for (int i = 1; i <= 100; i++) {
//			tableDTO = new TableDTO();
//			tableDTO.setTitle("Test title [" + i + "]");
//			tableDTO.setContent("Test Content : " + i);
//			tableDTO.setId("root");
//			
//			tableDAO.insert(tableDTO);
//			
//			Thread.sleep(1000); // 1초 재우기
//			
//			
//			
//		}
//		
//		
//	}
	
	
	
	
	
}
