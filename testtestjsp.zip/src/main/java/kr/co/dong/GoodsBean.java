package kr.co.dong;

public class GoodsBean {
	
	
	
}
