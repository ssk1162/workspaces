package kr.co.dong;

public class Test {
	public static void main(String[] args) {
		
		System.out.println("테스트");
		
		GoodsBean g = new GoodsBean();
		
		
	}
}
